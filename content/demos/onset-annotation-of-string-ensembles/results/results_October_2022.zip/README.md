List of files with results used in paper "Onset Annotation of String Ensembles" and the website https://arme-project.co.uk/demos/onset-annotation

Paper - Table1.csv
Paper - Table2.csv
Paper - Figure5.csv
Paper - Figure6.csv
Paper - Figure7.csv

Web - Figure5_types_per_annotator.csv - On the website Figure 1
Web - Figure6_per_inst.csv - On the website Figure 2
Web - Figure7_FPR.csv - On the website Figure 3
